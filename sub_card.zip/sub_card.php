<!DOCTYPE html>
<html lang="en">

<head>
    <title>Home Taste Hub</title>
    <?php include_once('includes/site-master.php') ?>
    <style>
        /* =======sec_card======== */
        .sec_card .inner {
            width: 23%;
            text-align: center;
            margin: 0 auto;
            color: #fff;
        }

        .sec_card .inner .inside {
            background-color: #15284b;
            position: relative;
        }

        .sec_card .inner .inside:before {
            position: absolute;
            bottom: -10px;
            left: 0;
            content: '';
            background: url(../images/sub_c_01.png);
            width: 34%;
            height: 34%;
            background-size: contain;
            background-repeat: no-repeat;
        }

        .sec_card .inner .inside:after {
            position: absolute;
            top: 0px;
            right: 0;
            content: '';
            background: url(../images/sub_c_2.png);
            width: 34%;
            height: 34%;
            background-size: contain;
            background-repeat: no-repeat;
        }

        .sec_card .inner .logo {
            width: 25%;
            margin: 10px auto;
            padding-top: 31px;
        }

        .sec_card .inner .logo img {
            filter: brightness(0) invert(1);
        }

        .sec_card .inner .scan {
            width: 33%;
            margin: 0 auto;
            margin-bottom: 14px;
        }

        .sec_card .inner h1 {
            margin: 0 auto;
            margin-bottom: 13px;
        }

        .sec_card .inner h6 {
            font-family: ui-serif;
            font-size: 17px;
            border-bottom: 1px dotted #fff;
            width: fit-content;
            margin: 0 auto;
            margin-bottom: 12px;
        }

        .sec_card .content {
            padding: 0 34px;
            padding-bottom: 15px;
        }

        .sec_card .content p {
            font-family: math;
            width: 73%;
            margin: 0 auto;
            font-size: 14px;
            margin-bottom: 13px;
        }

        .sec_card .content .id_it {
            margin-bottom: 0;
        }
    </style>
</head>

<body>
    <?php include_once('includes/header.php') ?>
    <!-- =========================banner=================== -->
    <main>
        <section class="sec_card">
            <div class="contain">
                <div class="inner">
                    <div class="inside">
                        <div class="logo">
                            <img src="images/logo-card.png" alt="">
                        </div>
                        <div class="content">
                            <h1>Members Card</h1>
                            <h6>Nathaniel Kelly</h6>
                            <p>Exclusive discounts off your dining experience</p>
                            <div class="scan">
                                <img src="images/sub_c_4.png" alt="">
                            </div>
                            <p class="id_it">Member ID: <br> 67249946</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>


    <?php include_once('includes/footer.php') ?>
    <?php include_once('includes/commonjs.php') ?>
</body>

</html>